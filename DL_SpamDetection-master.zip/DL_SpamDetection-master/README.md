# Deep Learning Techniques for Spam Detection
A set of different deep learning based approaches for detection of real/fake hotel reviews.

Dataset Used:
Deceptive Opinion Spam Corpus v1.4 <https://myleott.com/op-spam.html>
This corpus consists of 800 real and 800 fake online hotel reviews for the top 20 Chicago hotels.

